import os
from flask import Flask, render_template, request
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.prompts import PromptTemplate
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory

load_dotenv()

app = Flask(__name__)
openai_api_key = os.getenv("OPENAI_API_KEY")

# Load vector store and retriever
embedding = OpenAIEmbeddings(openai_api_key=openai_api_key)
vector_store = FAISS.load_local(
    "vector_store", embeddings=embedding, allow_dangerous_deserialization=True
)
retriever = vector_store.as_retriever(search_kwargs={"k": 4})

# Improved Prompt Template with formatting and polite closing
prompt_template = PromptTemplate(
    template="""
You are AskNuml, a knowledgeable and professional assistant for students and visitors at the National University of Modern Languages (NUML).

Your job is to provide well-structured, comprehensive, and clear answers using the provided context and previous conversation history. If relevant, use:
- Headings and subheadings
- Bullet points or numbered lists
- Tables (if necessary)
- A friendly and helpful tone

At the end of your answer, politely ask if more help is needed.
If the user asks something outside this domain (e.g., unrelated general knowledge, politics, etc.), politely respond:

"I'm here to help with NUML-related information only. Please ask something related to NUML"
Professionalism:
- If the user uses abusive or inappropriate language, remain calm and respond:
"Let's keep this a respectful and constructive conversation. I'm here to assist you with NUML-related questions."

Context:
{context}

Chat History:
{chat_history}

Question:
{question}

Answer:
""",
    input_variables=["context", "question", "chat_history"],
)

# Set up the ChatOpenAI model
chat_model = ChatOpenAI(openai_api_key=openai_api_key, temperature=0.5)

# Memory to track chat history
memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

# ConversationalRetrievalChain with memory and formatting
qa_chain = ConversationalRetrievalChain.from_llm(
    llm=chat_model,
    retriever=retriever,
    memory=memory,
    combine_docs_chain_kwargs={"prompt": prompt_template},
    return_source_documents=False,
)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def chatbot_response():
    user_input = request.form["msg"]
    result = qa_chain.run(user_input)
    return result

if __name__ == "__main__":
    app.run(debug=True)

from vector_build import build_vector_store

pdf_folder = "static/docs"
urls = [
    "https://www.numl.edu.pk/rector",
    "https://www.numl.edu.pk/about/bog",
    "https://www.numl.edu.pk/dg",
    "https://www.numl.edu.pk/about/history",
    "https://www.numl.edu.pk/about/values",
    "https://www.numl.edu.pk/about/vision-mission",
    "https://www.numl.edu.pk/about/objectives",
    "https://www.numl.edu.pk/faculty/128/about",
    "https://www.numl.edu.pk/department/178/faculty",
    "https://www.numl.edu.pk/department/178/about",
    "https://www.numl.edu.pk/programs/program/57",
    "https://www.numl.edu.pk/programs/program/59",
    "https://www.numl.edu.pk/programs/program/206",
    "https://www.numl.edu.pk/programs/program/352",
    "https://www.numl.edu.pk/programs/program/458",
    "https://www.numl.edu.pk/programs/program/459",
    "https://www.numl.edu.pk/programs/program/460",
    "https://www.numl.edu.pk/department/178/track/1",
    "https://www.numl.edu.pk/department/178/track/2",
    "https://www.numl.edu.pk/department/178/track/3",
    "https://www.numl.edu.pk/department/178/track/4",
    "https://www.numl.edu.pk/department/178/track/5",
    "https://www.numl.edu.pk/department/178/track/6",
    "https://www.numl.edu.pk/department/178/track/7",
    "https://www.numl.edu.pk/department/178/track/8",
    "https://www.numl.edu.pk/department/178/track/9",
    "https://www.numl.edu.pk/department/178/projects/2",
    "https://www.numl.edu.pk/department/178/contact",
    "https://www.numl.edu.pk/facilities",
    "https://numl.edu.pk/icect/",
    "https://numl.edu.pk/numlogic/",
]
print("Loading website data...")
build_vector_store(pdf_folder, urls)
print("Vector store build completed successfully.")

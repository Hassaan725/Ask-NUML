import os
from dotenv import load_dotenv
from langchain_community.document_loaders import PyPDFLoader, WebBaseLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS

load_dotenv()
openai_api_key = os.getenv("OPENAI_API_KEY")

def load_all_pdfs_from_folder(folder_path):
    docs = []
    for filename in os.listdir(folder_path):
        if filename.endswith(".pdf"):
            pdf_path = os.path.join(folder_path, filename)
            loader = PyPDFLoader(pdf_path)
            docs.extend(loader.load())
    return docs

from langchain_community.document_loaders import WebBaseLoader

def load_website_data(urls):
    all_data = []
    for url in urls:
        try:
            print(f"Loading: {url}")
            loader = WebBaseLoader(
                url,
                requests_kwargs={
                    "headers": {
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
                    },
                    "timeout": 10  # Avoid long waits
                }
            )
            documents = loader.load()
            all_data.extend(documents)
        except Exception as e:
            print(f"Failed to load {url}: {e}")
    return all_data


def build_vector_store(pdf_folder, urls, persist_path="vector_store"):
    print(f"Loading PDFs from: {pdf_folder}")
    pdf_docs = load_all_pdfs_from_folder(pdf_folder)

    print("Loading website data...")
    web_docs = load_website_data(urls)

    all_docs = pdf_docs + web_docs

    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)
    split_docs = splitter.split_documents(all_docs)

    print(f"Total chunks: {len(split_docs)}")
    embeddings = OpenAIEmbeddings(openai_api_key=openai_api_key)
    vector_store = FAISS.from_documents(split_docs, embedding=embeddings)
    vector_store.save_local(persist_path)
    print(f"Vector store saved to '{persist_path}'")

